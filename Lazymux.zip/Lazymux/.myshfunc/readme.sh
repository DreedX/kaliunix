
readme() {
# Usage: readme user repos
curl https://raw.githubusercontent.com/$1/$2/master/README.md
}
