<p align="center">
<img src="https://img.shields.io/badge/ECHO%20EN-MEXICO-SCRIPT?colorA=0000ff&colorB=CDCFD2&colorC=ff0000&style=for-the-badge">
</p>

![Banner_Git](https://i.ibb.co/9Wd8c72/Sin-t-tulo59.png) </a>

<p align="center">
<a href=https://github.com/venom-24><img title="github" src="https://img.shields.io/badge/VENOM-24-brightgreen?style=for-the-badge&logo=github"></a>
</p>
<p align="center">
<a href="https://www.youtube.com/c/Venom24Termux"><img title="youtube" src="https://img.shields.io/badge/YouTube-VeNOM24-red?style=for-the-badge&logo=Youtube"></a>
</p>

<p align="center">
<a href="https://github.com/venom-24"><img title="Followers" src="https://img.shields.io/github/followers/venom-24?color=blue&style=flat-square"></a> 
<a href="https://github.com/venom-24"><img title="Stars" src="https://img.shields.io/github/stars/venom-24/beef-24?color=blue&style=flat-square"></a>
<a href="https://github.com/venom-24"><img title="Forks" src="https://img.shields.io/github/forks/venom-24/beef-24?color=blue&style=flat-square">
</a> <a href="https://github.com/venom-24"><img title="Watching" src="https://img.shields.io/github/watchers/venom-24/beef-24?label=Watchers&color=blue&style=flat-square"></a>
</p>

# Disponible En :
* TERMUX

### Probado En :
* TERMUX
### Requerimientos :
* Conexion a internet
* 1 GB De Almacenamiento 

## COMANDOS DE INSTALACION DE BEEF

* `apt update`
* `apt upgrade -y`
* `git clone https://github.com/venom-24/beef-24.git`
* `ls`
* `cd beef-24;ls`
* `chmod +x *;ls`
* `ls`
* `./beef_venom24`

## screenshot
<br>
<p align="center">
<img width="50%" src="https://i.ibb.co/rZVvx08/Sin-t-tulo62.png"/>
<img width="48%" src="https://i.ibb.co/DKRJFz3/Sin-t-tulo61.png"/>
</p>

## Conectate con nosotros
[![Messenger](https://img.shields.io/badge/Chat-Messenger-blue?style=for-the-badge&logo=messenger)](https://m.me/venom.24.tr)
<a href="https://www.youtube.com/c/Venom24Termux"><img title="youtube" src="https://img.shields.io/badge/YouTube-VeNOM24-red?style=for-the-badge&logo=Youtube">
</a>
[![Telegram](https://img.shields.io/badge/Telegram-Channel-blue?style=for-the-badge&logo=telegram)](https://t.me/Vnom24)
<a href=https://www.facebook.com/Venom24termuxavanzado><img title="Facebook" src="https://img.shields.io/badge/FACEBOOK-DAME LIKE-blue?style=for-the-badge&logo=Facebook"></a>
</a>
[![Github](https://img.shields.io/badge/github-VENOM24-brightgreen?style=for-the-badge&logo=github)](https://github.com/venom-24)



