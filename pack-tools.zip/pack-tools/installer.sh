#! /data/data/com.termux/files/usr/bin/bash   
#Este code fue escrito por VeNOM24 


#VARIABLES                                              

             red='\033[1;31m'
             green='\033[1;32m'
             yellow='\033[1;33m'
             blue='\033[1;34m'
             magenta='\033[1;35m'
             cyan='\033[1;36m'
             reset='\033[0m'
cd --
ls
rm -rf pack-tools.zip	     
clear

printf $cyan

echo "###ACTUALIZANDO PAQUETES###"
sleep 2.0
apt update && apt upgrade
printf $cyan
echo "###INSTALANDO FIGLET###"
sleep 2.0
printf $reset
apt install figlet
printf $cyan
echo "###INSTALANDO UTIL-LINUX###"
sleep 2.0
echo -e '\033[0m'
apt install util-linux
printf $cyan                                            echo "###INSTALANDO GIT###"                            
sleep 2.0                                              
printf $reset
apt install git
printf $cyan
echo "###INSTALANDO PYTHON###"                         
sleep 2.0                                              
printf $reset
apt install python
printf $cyan  
echo "###INSTALANDO PYTHON2"
sleep 2.0
printf $reset
apt install python2
printf $cyan
echo "###INSTALANDO SHELL FISH###"                     
sleep 2.0                                              
printf $reset
apt install fish
printf $cyan
echo "MEMORIA INTERNA"                                 
sleep 2.0                                              
printf $reset                                       
termux-setup-storage                             
printf $cyan       
echo "###INSTALANDO CURL###"    
sleep 2.0  
printf $reset
apt install curl

cd --
cd $HOME/pack-tools/
ls
printf $cyan
echo "###INSTALANDO SQLMAP###"
sleep 2.0
printf $reset
git clone https://github.com/sqlmapproject/sqlmap.git
printf $cyan
echo "###INSTALANDO WEEMAN###"
sleep 2.0
printf $reset
git clone https://github.com/evait-security/weeman.git
printf $cyan
echo "###INSTALANDO LAZYMUX###"
sleep 2.0
printf $reset
git clone https://github.com/Gameye98/Lazymux.git
cd --
cd $HOME/pack-tools/
ls
cp packtools.sh /data/data/com.termux/files/usr/bin

bash $HOME/pack-tools/packtools.sh


