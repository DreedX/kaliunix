#! /dataa/data/com.termux/files/usr/bin/bash/
                                                        clear                                                   #este code es escrito por venom24                                                                               #variables                                             
														               red='\033[1;31m'                                        green='\033[1;32m'                                      yellow='\033[1;33m'                                     blue='\033[1;34m'                                       magenta='\033[1;35m'                                    cyan='\033[1;36m'                                       reset='\033[0m'
														       
printf $red

echo "
░█▀█░█▀█░█▀▀░█░█░▀█▀░█▀█░█▀█░█░░░█▀▀
░█▀▀░█▀█░█░░░█▀▄░░█░░█░█░█░█░█░░░▀▀█
░▀░░░▀░▀░▀▀▀░▀░▀░░▀░░▀▀▀░▀▀▀░▀▀▀░▀▀▀"
							echo -e '\033[1;36m'	       
echo "AUTOR:    VeNOM24"
echo "TOOL:     PACKTOOLS"                            
echo "VERSION:  1.0"
echo -e '\033[1;31m'
echo "[ PAQUETES INSTALADOS ]"
echo -e '\033[1;33m'
echo "figlet util-linux git python python2 fish storage curl"
echo -e '\033[1;31m'
echo "[ TOOLS INSTALADAS ]"
echo
echo -e "\e[0;34m[01]\033[1;33msqlmap\033[0;34m"
echo -e "\e[0;34m[02]\033[1;33mweeman\033[0;34m"
echo -e "\e[0;34m[03]\033[1;33mlazymux\033[0;34m"
echo -e "\e[0;34m[04]\033[1;33mfish\033[0;34m"
echo -e "\e[0;34m[05]\033[1;33mfiglet\033[0;34m"
echo -e "\e[0;34m[00]\033[1;33mcode\033[0;34m"
echo ""

function reiniciar {
        echo $(clear)                                
	bash $HOME/pack-tools/packtools.sh

}

#Menu
echo -e "\e[1;36m"
echo -n "SELECT YOUR TOOL #>> ";

read opcion

echo -e '\033[0m'


case $opcion in                                         01)echo ""
cd --
cd $HOME/pack-tools/sqlmap
cd sqlmap
ls
chmod +x sqlmap.py
ls
clear
python2 sqlmap.py


;;

02) 
cd --	
cd $HOME/pack-tools/weeman
cd weeman
ls
chmod +x weeman.py
ls
clear
python2 weeman.py


;;

03)
cd --	
cd $HOME/pack-tools/Lazymux
cd Lazymux
ls
chmod +x lazymux.py
ls
clear
python lazymux.py

;;

04)
clear	
fish
ls

;;

05)
showfigfonts
ls

;;

00)echo 
printf $red
echo "AUTOR: Venom24"
echo "BOT DE TELEGRAM: https://t.me/VENOM24_BOT"
echo "CANAL DE TELEGRAM: https://t.me/Vnom24"
echo "BanderaBlancaHackingEtico" 
printf $magenta
figlet -f smslant Venom24
printf $reset

;;

*)
printf $red
echo "LO CIENTO TU ELECCION NO ESTA"
sleep 1.5
reiniciar
    
printf $reset

esac

