<h1> Tool-Termux-Nethunter </h1>

<h4> Script Feito pra Automatiza a Instalação do Nethunter no 'Termux sem Root' </4>
<h4> Esse NetHunter Foi Modificado !! Adicionei as seguintes Ferramentas :: </h4>
<h3> Metasploit-Framework </h3>
<h3> SetoolKit </h3>
<h3> Ngrok </h3>
<h3> Apache2 </h3>
<h3> Atscan </h3>
<h3> Sqlmap </h3>
<h4> Alguns pacotes Tiveram umas pequenas modificações pra si adaptar com o Termux! </h4>
<h4> modo de usar:: </h4>

<h4> pkg install git -y;git clone https://github.com/noobfoda2/tool;cd tool;chmod +x kali;bash kali </h4>

<h4> grupo no telegram :: http://t.me/nethunter01 </4>

<h4> @NoobFoda2 </h4>

<h2> MENU </h2>

![img](http://i.imgur.com/fvXwggv.jpg)

<h2> OPENSSH ! ACESSANDO O TERMUX VIA SSH PELO APP 'TERMIUS' </h2>

![img](http://i.imgur.com/2OvwXhe.jpg)

<h2> KALI-NETHUNTER ! NGROK ! </h2

![img](http://i.imgur.com/6lxyFWs.jpg)

<h2> METASPLOIT-FRAMEWORK ! INVANDINDO SISTEMA ANDROID </h2>

![img](http://i.imgur.com/lcymaxO.jpg)

<h2> ATSCAN+SQLMAP </h2>

![img](http://i.imgur.com/Hyi00Qj.jpg)
