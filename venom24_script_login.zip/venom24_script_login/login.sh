#! /data/data/com.termux/files/usr/bin/bash/

# hola elegidos para ser hackers hoy vamos a realizar un login de termux

# gira tu pantalla en modo orizontal para que tengas una mejor vision de este script

#para realizar este script es nesesario tener un teclado como el mio es hacker keyboard descargatelo el link esta en la descripcion del video.

#variables

       passwd="2468"
  	
       echo  $passwd
	


#funciones
	
      function reinicio {
	
	   echo $(clear)
	
# setterm, comando le da color al banner	
	setterm -foreground cyan
echo               "#===================================#"
echo               "#      HOLA BIENVENIDOS A TERMUX    #"
echo               "#           INICIA SESSION          #"
echo               "#      ELEGIDOS PARA SER HACKERS    #"
echo               "#===================================#"
	
	read -p "                ESCRIBE TU PASSWORD >> " passwd1
	setterm -foreground white
}
reinicio

# el comando while, es un bucle que compara las variables ejemplo si el valor de la variable passwd1 es desigual a el valor de la variable passwd, lo que procede es que si estas 2 variables no coinciden, aqui estamos indicando que se reinici el script y que siga preguntando escribe tu password.

while [ $passwd1 != $passwd ] ;do
	reinicio
done
# este candicional if sirve para crear una condicion,nuestra condicion es, si el valor de la variable $passwd1 es igual al valor de la variable $passwd,aqui estamos que entonces que limpie la pantalla y nos brinde el acceso a termux,

if [ $passwd1 = $passwd ] ; then

	clear
# este comando else ya no se ejecuto en el video, porque la condicion si se dio, el valor de la variable $passwd1 fue igual al valor de la variable $passwd, de lo contrario, se huviese reiiniciado el script, y hubiese vuelto a preguntar scribe tu password
else
	reinicio
fi
 
#bien, elegidos para ser hackers aqui les dejo este script para que lo analizen, lo estudien, y sobre todo lo practiquen nos vemos muy pronto yo soy venom24 chauuuuuuuuuuuu

#https://www.youtube.com/c/venom24_R
